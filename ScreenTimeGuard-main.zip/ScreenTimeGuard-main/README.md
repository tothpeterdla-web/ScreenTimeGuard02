# ScreenTimeGuard
An app that limits your screentime, secured with a pin, system apps will still be usable, set it up on a pure phone or do a factory reset before doing it.
